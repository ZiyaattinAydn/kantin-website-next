import type { BranchId, MerchProduct } from "./domain";

export type ImageAsset = {
  src: string;
  width: number;
  height: number;
};

export type MerchDoodle = {
  src: string;
  className: string;
};

export type MerchProductContent = MerchProduct & {
  index: string;
  detail: string;
  image: string;
  imageAlt: string;
  backImage?: string;
  backImageAlt?: string;
};

export type MerchBundle = {
  name: string;
  price: number;
};

export type HomeMenuBranch = {
  slug: BranchId;
  code: string;
  name: string;
  image?: ImageAsset;
  title: string;
  description: string;
  tags: string[];
  delayClass?: string;
};

export type LocationBranch = {
  slug: BranchId;
  code: string;
  visualClass: string;
  eyebrow: string;
  title: string;
  address: string;
  description?: string;
  mapsUrl: string;
  images: ImageAsset[];
  delayClass?: string;
};

export type NavigationItem = {
  href: string;
  label: string;
  exact?: boolean;
};

export type FooterLink = {
  href: string;
  label: string;
  external?: boolean;
};

export type InstagramPost = {
  id: string;
  image: string;
  imageAlt: string;
  caption: string;
  branch: string;
  publishedAt: string;
  permalink: string;
};
